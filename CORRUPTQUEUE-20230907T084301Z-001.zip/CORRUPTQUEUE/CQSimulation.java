public class CQSimulation
{
	public static void main(String[] args)
	{
		CorruptQueue cq = new CorruptQueue();
		cq.run();
	}
}