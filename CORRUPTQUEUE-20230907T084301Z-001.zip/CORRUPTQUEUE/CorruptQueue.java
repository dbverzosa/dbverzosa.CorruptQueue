import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CorruptQueue
{
	// Line for the regulars (uses Queue since it is first in first out basis)
	private RQueue RegularQueue;
	// Line for VIPs (uses Stack since it is last-in first-out)
	private VStack VIPStack;

	// checks if supervisor is present or not
	private boolean supPresent;

	public CorruptQueue()
	{
		// Instantiate both variables
		RegularQueue = new RQueue();
		VIPStack = new VStack();
		supPresent = false;
	}

	public void run()
	{
		// open the file
		try(Scanner sc = new Scanner(new File("officeinput.txt")))
		{
			// read until end
			while(sc.hasNextLine())
			{
				String ln = sc.nextLine();

				// if someone is lining up
				if(ln.startsWith("lineup"))
				{
					String[] lnsplit = ln.split(",");
					String name = lnsplit[1];
					String type = lnsplit[2];

					// if supervisor is present then lineup normally
					if(supPresent)
					{
						// enqueue the name of the client to the RegularQueue
						RegularQueue.enqueue(name);

						switch(type)
						{
							case "regular":
								System.out.println("Regular client " + name + " lines up at RegularQueue");
								break;
							case "VIP":
								System.out.println("VIP client " + name + " lines up at RegularQueue");
								break;
							default:
								// nothing
						}
						

						// skip everything else since supervisor is present
						continue;
					}

					// check if regular or VIP if supervisor isn't present
					switch(type)
					{
						case "regular":
							// push the name of the client to the RegularQueue
							RegularQueue.enqueue(name);
							System.out.println("Regular client " + name + " lines up at RegularQueue");
							break;
						case "VIP":
							// enqueue the name of the client to the VIPStack
							VIPStack.push(name);
							System.out.println("VIP client " + name + " lines up at VIPStack");
							break;
						default:
							// nothing
					}
				}

				// if serving
				else if(ln.startsWith("serve"))
				{
					if(!VIPStack.isEmpty())
					{
						System.out.println("Now serving " + VIPStack.pop() + " from VIPStack");
					}
					else
					{
						if(!RegularQueue.isEmpty())
						{
							System.out.println("Now serving " + RegularQueue.dequeue() + " from RegularQueue");
						}
						else
						{
							System.out.println("RegularQueue empty");
						}
					}
				}

				// if suppervisor arrives
				else if(ln.startsWith("arrive"))
				{
					String popped = null;

					while((popped = VIPStack.pop()) != null)
					{
						RegularQueue.enqueue(popped);
					}

					supPresent = true;
					System.out.println("Supervisor present");
				}

				// if supervisor leaves
				else if(ln.startsWith("leave"))
				{
					supPresent = false;
					System.out.println("Supervisor not here");
				}
			}
		}
		catch(FileNotFoundException e)
		{
			System.out.println(e);
		}
	}
}