public class Node
{
	// The data inside the Node
    private String data;
    private Node nextNode;

    public Node(String data)
	{
        this.data = data;
		nextNode = null;
    }

	public String getName()
	{
		return data;
	}

	public Node getNext()
	{
		return nextNode;
	}

	public void setNext(Node node)
	{
		nextNode = node;
	}
}