public class RQueue
{
	// Pointer to first in the queue
	private Node first;
	// Pointer to last in the queue
	private Node last;

	public RQueue()
	{
		// Assign both to null to imply queue is empty
		first = null;
		last = null;
	}

	public void enqueue(String name)
	{
		// Create the client to add to the line
		Node temp = new Node(name);

		// if queue is empty, set it to first and last
		if(first == null)
		{
			first = last = temp;
		}
		// if not then reference it to the current last and set it to be the new last
		else
		{
			last.setNext(temp);
			last = temp;
		}
	}

	public String dequeue()
	{
		// if stack is empty return nothing
		if(first == null)
			return null;

		// Get the first in line and go to next
		String name = first.getName();
		first = first.getNext();

		// return the first in line
		return name;
	}

	public boolean isEmpty()
	{
		return first == null;
	}
}