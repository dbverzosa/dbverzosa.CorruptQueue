public class VStack
{
	// Pointer to top of the stack
	private Node top;

	public VStack()
	{
		// Assign to null to imply stack is empty
		top = null;
	}

	public void push(String name)
	{
		// Create the client to add to the line
		Node temp = new Node(name);

		// if stack is empty, set it to top
		if(top == null)
		{
			top = temp;
		}
		// if not then reference the current top to it and set it to be the new top
		else
		{
			temp.setNext(top);
			top = temp;
		}
	}

	public String pop()
	{
		// if stack is empty return nothing
		if(top == null)
			return null;

		// get the top and move to next
		String name = top.getName();
		top = top.getNext();

		// return the top of the stack
		return name;
	}

	public boolean isEmpty()
	{
		return top == null;
	}
}